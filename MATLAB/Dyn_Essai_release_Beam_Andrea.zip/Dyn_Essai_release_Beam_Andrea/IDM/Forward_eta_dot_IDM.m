function dy = Forward_eta_dot_IDM(X,y,t,Const,Config)

% calcul la seconde ode spaciale 
% Integration spaciale de 0->1
% entr�es
% q       = y(1:4)  ; % orientation de la section
% r       = y(5:7)  ; % position de la section
% eta     = y(8:13) ; % vitesse de la section
% F_tilde = y(14:19); % Effort de la section
% S       = y(20:55); % Matrice S
% s       = y(56:61); % vecteur s
% eta_dot = y(62:67); % acceleration de la section
% sorties
% dy(1:4,1)   = q_prime  ;     % orientation de la section
% dy(5:7,1)   = r_prime  ;     % position de la section
% dy(8:13,1)  = eta_prime ;    % vitesse de la section
% dy(14:19,1) = F_tilde_prime; % Effort de la section
% dy(20:55,1) = S_prime;       % Matrice S
% dy(56:61,1) = s_prime;       % vecteur s
% dy(62:67,1) = eta_dot_prime  % acceleration de la section


%-------------- entr�es -----------------%

q       = y(1:4)  ; % orientation de la section
r       = y(5:7)  ; % position de la section
eta     = y(8:13) ; % vitesse de la section
F_tilde = y(14:19); % Effort de la section
S_vec   = y(20:55); % Matrice S
s       = y(56:61); % vecteur s
eta_dot = y(62:67); % acceleration de la section

S = reshape(S_vec,[6 6]);
%-------------- for�age -----------------%

Phi = Base_Phi(X,t);

Xi_a = Phi'*Const.r;
Xi_dot_a = Phi'*Const.r_dot;
Xi_dot_dot_a = Phi'*Const.r_dot;

Xi = Const.A*Xi_a +  Const.A_bar*Const.Xi_c;
Xi_dot = Const.A*Xi_dot_a;
Xi_dot_dot = Const.A*Xi_dot_dot_a;
%-------------- calculs -----------------%

A = Const.A;
M_cal = Const.M_cal;
M_cal_prime = Const.M_cal_prime;

[~,~,~,F_bar_prime] = Forces_exterieur(X,q,r,eta);

Pxx = -ad_(Xi);
Pxy = zeros(6,6);
Pyx = M_cal;
Pyy = ad_(Xi)';

px = Xi_dot_dot - ad_(Xi_dot)*eta;
py = -F_tilde;
    

q_prime   = quaternion_dot(q,Xi(1:3));
r_prime   = r_dot(q,Xi(4:6));
eta_prime = -ad_(Xi)*eta + Xi_dot;

F_tilde_prime = F_bar_prime + ad_(eta_prime)'*M_cal*eta + ad_(eta)'*(M_cal_prime*eta + M_cal*eta_prime);

S_prime = Pyx - S*Pxx + Pyy*S - S*Pxy*S;
s_prime = Pyy*s + py - S*Pxy*s - S*px;
eta_dot_prime = (Pxx+Pxy*S)*eta_dot + Pxy*s+px;


%-------------- sorties -----------------%
S_prime_vec = reshape(S_prime,[36,1]);

dy(1:4,1)   = q_prime  ;     % orientation de la section
dy(5:7,1)   = r_prime  ;     % position de la section
dy(8:13,1)  = eta_prime ;    % vitesse de la section
dy(14:19,1) = F_tilde_prime; % Effort de la section
dy(20:55,1) = S_prime_vec;   % Matrice S
dy(56:61,1) = s_prime;       % vecteur s
dy(62:67,1) = eta_dot_prime; % acceleration de la section

